package ar.org.centro8.java.entities;

public class AutoNuevo extends Vehiculo {



        public AutoNuevo(String marca, String color, String modelo, String marcaRadio, int potencia) {
            super(marca, color, modelo, marcaRadio, potencia);
        }
    
    
    
    
        public AutoNuevo(String marca, String color, String modelo, double precio, String marcaRadio, int potencia) {
            super(marca, color, modelo, precio, marcaRadio, potencia);
        }
    
}
