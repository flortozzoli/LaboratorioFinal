package ar.org.centro8.java.entities;

public class AutoClasico extends Vehiculo {
    public AutoClasico(String marca, String color, String modelo) {
        super(marca, color, modelo);
    }


    public AutoClasico(String marca, String color, String modelo, String marcaRadio, int potencia) {
        super(marca, color, modelo, marcaRadio, potencia);
    }


    public AutoClasico(String marca, String color, String modelo, double precio) {
        super(marca, color, modelo, precio);
    }


    
    public AutoClasico(String marca, String color, String modelo, double precio, String marcaRadio, int potencia) {
        super(marca, color, modelo, precio, marcaRadio, potencia);
    }


    @Override
    public String toString() {
        return "Auto Clasico: "+ super.toString();

        

    
}

    
}
